package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.media.AudioManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import static android.content.Context.AUDIO_SERVICE;

public class CustomKeyboard  extends AppCompatActivity {

    public final static int CodeDelete   = -5; // Keyboard.KEYCODE_DELETE
    public final static int CodeCancel   = -3; // Keyboard.KEYCODE_CANCEL
    public final static int CodePrev     = 55000;
    public final static int CodeAllLeft  = 55001;
    public final static int CodeLeft     = 55002;
    public final static int CodeRight    = 55003;
    public final static int CodeAllRight = 55004;
    public final static int CodeNext     = 55005;
    public final static int CodeClear    = 55006;

    private KeyboardView mKeyboardView;
    private AppCompatActivity activity;
    private boolean isCaps= false;

    CustomKeyboard(AppCompatActivity host, int viewid, int layoutid) {
        activity = host;
        Keyboard mKeyboard = new Keyboard ( activity, layoutid );


        mKeyboardView = activity.findViewById(viewid);

        mKeyboardView.setKeyboard( mKeyboard );

        mKeyboardView.setPreviewEnabled(false);
        mKeyboardView.setOnKeyboardActionListener(mOnKeyboardActionListener);
// Hide the standard keyboard initially
          activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

    }
    boolean isCustomKeyboardVisible() {
        return mKeyboardView.getVisibility() == View.VISIBLE;
    }

    private void showCustomKeyboard(View v) {
        mKeyboardView.setVisibility(View.VISIBLE);
        mKeyboardView.setEnabled(true);
        if( v!=null ) ((InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    void hideCustomKeyboard() {
        mKeyboardView.setVisibility(View.GONE);
        mKeyboardView.setEnabled(false);
    }

    @SuppressLint("ClickableViewAccessibility")
    void registerEditText(int resid) {

        EditText edittext;
        edittext = activity.findViewById(resid);
        // Make the custom keyboard appear
        edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                if( hasFocus ) showCustomKeyboard(v); else hideCustomKeyboard();
            }
        });
        edittext.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                showCustomKeyboard(v);
            }
        });

        edittext.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                EditText edittext = (EditText) v;
                int inType = edittext.getInputType();       // Backup the input type
                edittext.setInputType(InputType.TYPE_NULL); // Disable standard keyboard
                edittext.onTouchEvent(event);               // Call native handler
                edittext.setInputType(inType);              // Restore input type
                return true; // Consume touch event
            }
        });


        // Disable spell check (hex strings look like words to Android)
        edittext.setInputType( edittext.getInputType() | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS );
    }

    private KeyboardView.OnKeyboardActionListener mOnKeyboardActionListener;

    {
        mOnKeyboardActionListener = new KeyboardView.OnKeyboardActionListener ( ) {
            @Override
            public void onPress(int primaryCode) {

            }

            @Override
            public void onRelease(int primaryCode) {

            }

            @Override
            public void onKey(int primaryCode, int[] keyCodes) {
                try {
                    playClick ( primaryCode );
                    View focusCurrent = activity.getWindow ( ).getCurrentFocus ( );


           /*

             if( focusCurrent==null || focusCurrent.getClass()!= EditText.class ) return;

             */
                    EditText edittext = (EditText) focusCurrent;
                    assert edittext != null;
                    Editable editable = edittext.getText ( );
                    int start = edittext.getSelectionStart ( );

                    if (primaryCode == CodeCancel) {
                        hideCustomKeyboard ( );
                    } else if (primaryCode == CodeDelete) {
                        if (editable != null && start > 0) editable.delete ( start - 1, start );
                    } else if (primaryCode == CodeClear) {
                        if (editable != null) editable.clear ( );
                    } else if (primaryCode == CodeLeft) {
                        if (start > 0) edittext.setSelection ( start - 1 );
                    } else if (primaryCode == CodeRight) {
                        if (start < edittext.length ( )) edittext.setSelection ( start + 1 );
                    } else if (primaryCode == CodeAllLeft) {
                        edittext.setSelection ( 0 );
                    } else if (primaryCode == CodeAllRight) {
                        edittext.setSelection ( edittext.length ( ) );
                    } else if (primaryCode == CodePrev) {

                        @SuppressLint("WrongConstant") View focusNew = edittext.focusSearch ( View.FOCUS_BACKWARD );
                        if (focusNew != null) focusNew.requestFocus ( );
                    } else if (primaryCode == CodeNext) {
                        @SuppressLint("WrongConstant") View focusNew = edittext.focusSearch ( View.FOCUS_FORWARD );
                        if (focusNew != null) focusNew.requestFocus ( );
                    } else {// Insert character
                        // editable.insert(start, Character.toString((char) primaryCode));
                        editable.insert ( start, toRussian ( primaryCode ) );

                    }
                } catch (Exception ex) {
                    Log.e ( "From CustomKeyboard", ex.getMessage ( ) );
                    Toast.makeText ( activity, ex.getMessage ( ), Toast.LENGTH_SHORT ).show ( );

                }
            }

            private void playClick(int primaryCode) {
            }

            private String toRussian(int code) {
                switch (code) {
                    case 169:
                        return "й";
                    case 230:
                        return "ц";
                    case 227:
                        return "у";
                    case 170:
                        return "к";
                    case 165:
                        return "е";
                    case 241:
                        return "ё";
                    case 173:
                        return "н";
                    case 163:
                        return "г";
                    case 232:
                        return "ш";
                    case 233:
                        return "щ";
                    case 167:
                        return "з";
                    /* 2 row */
                    case 228:
                        return "ф";
                    case 235:
                        return "ы";
                    case 162:
                        return "в";
                    case 160:
                        return "а";
                    case 175:
                        return "п";
                    case 224:
                        return "р";
                    case 174:
                        return "о";
                    case 171:
                        return "л";
                    case 164:
                        return "д";
                    case 166:
                        return "ж";
                    case 237:
                        return "э";
                    case 239:
                        return "я";
                    case 231:
                        return "ч";
                    case 225:
                        return "с";
                    case 172:
                        return "м";
                    case 168:
                        return "и";
                    case 226:
                        return "т";
                    case 236:
                        return "ь";
                    case 161:
                        return "б";
                    case 238:
                        return "ю";
                    case 107:
                        return "I";
                    case 234:
                        return "ъ";
                    /* row 3 */

                    /* 3 row */
                    default:
                        return Character.toString ( (char) code );
                }
            }

            /*


             */

            @Override
            public void onText(CharSequence text) {

            }

            @Override
            public void swipeLeft() {

            }

            @Override
            public void swipeRight() {

            }

            @Override
            public void swipeDown() {

            }

            @Override
            public void swipeUp() {

            }

        };
    }
}
