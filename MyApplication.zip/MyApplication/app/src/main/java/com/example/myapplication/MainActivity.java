package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String[] items;
    ArrayList<String> listItems;
    ArrayAdapter<String> adapter;
    ListView listView;
    EditText editText;

    CustomKeyboard mCustomKeyboard;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        mCustomKeyboard= new CustomKeyboard(this, R.id.keyboardview, R.xml.keyboard );


        listView  =( ListView )  findViewById ( R.id.listview );
        EditText editText = (EditText) findViewById ( R.id.txtsearch);
        mCustomKeyboard.registerEditText(R.id.txtsearch);
        initList();

        editText.addTextChangedListener(new TextWatcher () {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().equals("")){
                    // reset listview
                    initList();
                } else {
                    // perform search
                    //  searchItem(s.toString());
                    (MainActivity.this).adapter.getFilter().filter(s);
                }
            }
            @Override
            public void afterTextChanged(Editable s) {
            }

        });
        Toolbar toolbar = findViewById ( R.id.toolbar );
        setSupportActionBar ( toolbar );

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater ( ).inflate ( R.menu.menu_main, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.


        int id = item.getItemId ( );

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            Intent SecAct = new Intent ( getApplicationContext ( ), SecondActivity.class );
            startActivity ( SecAct );
        }
        if(id== R.id.data_act){
            Intent DatAct=new Intent (getApplicationContext(), DataActivity.class);
            startActivity(DatAct);
        }
        return super.onOptionsItemSelected ( item );
    }

    public void searchItem(String textToSearch){
        for(String item:items){
            if(!item.contains(textToSearch)){
                listItems.remove(item);
            }
        }
        adapter.notifyDataSetChanged();
    }

    public   ArrayList<String> getFileData(){
        InputStream inputStream = getResources().openRawResource(R.raw.file);
        ArrayList<String> list = new ArrayList<>();
        BufferedReader r = new BufferedReader(new InputStreamReader (inputStream));
        try {
            for (String line; (line = r.readLine()) != null; ) {
                list.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    public void initList()  {
        items= new String[] {   };
        // listItems=new ArrayList<> ( Arrays.asList(items));//
        listItems= Helper.getFileResource(this, R.raw.file);
        adapter=new ArrayAdapter<String> (this, R.layout.list_item, R.id.txtitem, listItems);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Helper.onShowDialog(getBaseContext(),"", listItems.get(position));
                String s = (Helper.getFileResource(getBaseContext(), R.raw.file_2)).get(position);
               Log.e("msic: ", s);
               Helper.onShowDialog(MainActivity.this, listItems.get(position), s);
            }
        });
    }
    @Override public void onBackPressed() {
        if( mCustomKeyboard.isCustomKeyboardVisible() ) mCustomKeyboard.hideCustomKeyboard(); else this.finish();
    }


    public void onShowDialog(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(title)
                .setMessage(message)
                .setCancelable(true)

                .setNegativeButton("Закрыть", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setPositiveButton ("Поделиться", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        intent.putExtra(Intent.EXTRA_SUBJECT, "_SUBJECT_");
                        intent.putExtra(Intent.EXTRA_TEXT, "_BODY_");
                        startActivity(Intent.createChooser(intent, getString(R.string.app_name)));
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

}