package com.example.myapplication;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;

public class TestAc extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_ac);

        CustomKeyboard mCustomKeyboard= new CustomKeyboard(this, R.id.keyboardview, R.xml.keyboard);
        EditText editText = (EditText) findViewById ( R.id.txtsearch);
        mCustomKeyboard.registerEditText(R.id.txtsearch);

    }
}
