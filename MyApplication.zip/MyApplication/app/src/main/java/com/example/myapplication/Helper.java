package com.example.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Helper {


    public static ArrayList<String> getFileResource(Context context, int resourceId){
        InputStream inputStream = context.getResources().openRawResource(resourceId);
        ArrayList<String> list = new ArrayList<>();
        BufferedReader r = new BufferedReader(new InputStreamReader(inputStream));
        try {
            for (String line; (line = r.readLine()) != null; ) {
                list.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }



   public static void onShowDialog(final Context context, String title, final String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setTitle(title)
                .setMessage(message)
                .setCancelable(true)

                .setNegativeButton("Закрыть", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setPositiveButton("поделиться", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        intent.putExtra(Intent.EXTRA_SUBJECT, "SUBJECT");
                        intent.putExtra(Intent.EXTRA_TEXT, message);
                       context.startActivity(Intent.createChooser(intent, context.getString(R.string.app_name)));
                    }
                })
        .setNeutralButton("возпроизвести", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }

        });
        AlertDialog alert = builder.create();
        alert.show();
    }


}